package org.example;

public interface Insurable {
    double calculateInsuranceCost();
}