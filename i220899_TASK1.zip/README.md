# car-rental-system
to run the app, run the following bash command:
```bash
./build.sh
```